#!/bin/bash
set -e

cd "$(dirname "$0")"

python3 -m venv .venv
. .venv/bin/activate

python -m pip install --upgrade pip
python -m pip install playwright pyinstaller
python -m playwright install chromium

echo
echo "Mac setup is done. You can start the app with Mac-start.command."

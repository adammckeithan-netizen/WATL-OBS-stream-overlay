@echo off
setlocal
cd /d "%~dp0"

if exist ".venv\Scripts\activate.bat" (
  call ".venv\Scripts\activate.bat"
)

python -m PyInstaller --noconsole --onefile ^
  --name "WATL-Overlay-Windows" ^
  --add-data "Windows-overlay.html;." ^
  --add-data "Windows-scores.json;." ^
  Windows-App.py

echo.
echo Windows app build is in the dist folder.
pause

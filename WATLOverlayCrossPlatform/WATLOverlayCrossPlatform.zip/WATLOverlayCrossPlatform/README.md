# WATL Overlay App - Mac and Windows

This folder has separate Mac and Windows launch files, but both use the same shared app code so the overlays stay matched.

## Mac Files

- `Mac-README.md`
- `Mac-setup.sh`
- `Mac-setup.command`
- `Mac-start.command`
- `Mac-App.py`
- `Mac-overlay.html`
- `Mac-scores.json`

## Windows Files

- `Windows-README.md`
- `Windows-setup.bat`
- `Windows-start.bat`
- `Windows-App.py`
- `Windows-overlay.html`
- `Windows-scores.json`

## Shared File

- `OverlayCore.py`

Keep the files together in the same folder unless you build a packaged app.

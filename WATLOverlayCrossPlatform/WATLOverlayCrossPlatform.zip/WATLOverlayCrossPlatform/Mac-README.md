# WATL Overlay App - Mac

Use these files on a Mac:

- `Mac-setup.sh` installs what the app needs.
- `Mac-setup.command` is the double-click setup shortcut.
- `Mac-start.command` starts the app.
- `Mac-App.py` is the Mac launcher.
- `Mac-overlay.html` is the Mac OBS overlay page.
- `Mac-scores.json` is the Mac live score data file.
- `Mac-build-app.sh` is optional and builds a Mac app file.

## First Setup

Double-click `Mac-setup.command`, or right-click it and choose Open.

If macOS asks for permission, allow it. Setup only needs to be done once.

## Start The App

Double-click `Mac-start.command`.

Paste the tournament URL, choose how many lane overlays you need, enter the lane numbers, then press Start.

## OBS Links

The app shows these OBS Browser Source links:

- All live lanes
- Scrolling Overlay
- One copy button for each selected stream lane

The Scrolling Overlay skips the lanes selected for stream overlays.

## Optional Build

Run `Mac-build-app.sh` to create a packaged Mac app in the `dist` folder.

"""
Shared cross-platform WATL overlay app core.

Mac-App.py and Windows-App.py both use this file so the two apps stay in sync.
"""

from __future__ import annotations

import functools
import http.server
import io
import json
import os
import queue
import re
import shutil
import sys
import threading
import time
import traceback
import tkinter as tk
import webbrowser
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from tkinter import ttk
from urllib.parse import urlencode


if sys.stdout is None:
    sys.stdout = io.TextIOWrapper(open(os.devnull, "wb"))
if sys.stderr is None:
    sys.stderr = io.TextIOWrapper(open(os.devnull, "wb"))

try:
    from playwright.sync_api import sync_playwright
except Exception as import_error:  # pragma: no cover - shown in the app at runtime
    sync_playwright = None
    PLAYWRIGHT_IMPORT_ERROR = import_error
else:
    PLAYWRIGHT_IMPORT_ERROR = None


SERVER_PORT = 8123
POLL_SECONDS = 2
STATS_REFRESH_EVERY = 12
DEFAULT_URL = (
    "https://axethrowing.org/drengr-axe-throwing-bedford-tx/tournament/view/"
    "sam_stream_test_hatchet?tournamentStatus=tournamentsFinished"
    "&tournamentSlug=sam_stream_test_hatchet"
)


@dataclass(frozen=True)
class PlatformConfig:
    platform_name: str
    overlay_filename: str
    scores_filename: str
    crash_log_filename: str
    app_title: str = "WATL Overlay App"


def _app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def _resource_dir() -> Path:
    bundle_dir = getattr(sys, "_MEIPASS", None)
    if bundle_dir:
        return Path(bundle_dir).resolve()
    return Path(__file__).resolve().parent


def ensure_runtime_files(config: PlatformConfig) -> Path:
    app_dir = _app_dir()
    resource_dir = _resource_dir()
    app_dir.mkdir(parents=True, exist_ok=True)

    for filename in (config.overlay_filename, config.scores_filename):
        target = app_dir / filename
        source = resource_dir / filename
        should_copy = not target.exists() or (
            filename == config.overlay_filename and getattr(sys, "frozen", False)
        )
        if should_copy and source.exists() and source != target:
            shutil.copy2(source, target)

    scores_path = app_dir / config.scores_filename
    if not scores_path.exists():
        scores_path.write_text(
            json.dumps(
                {
                    "updated_at": datetime.now(timezone.utc).isoformat(),
                    "active_matches": [],
                    "has_live": False,
                    "tournament_status": None,
                },
                indent=2,
            )
        )

    return app_dir


LIVE_JS = """
() => {
  const laneNumberFrom = text => {
    const match = String(text || '').match(/Lane\\s*(\\d+)/i);
    return match ? parseInt(match[1], 10) : null;
  };
  const arenaLaneNumber = text => {
    const match = String(text || '').match(/(\\d+)\\s*$/);
    return match ? parseInt(match[1], 10) : null;
  };
  const bracketLetter = game => {
    const value = String((game && game.bracket) || '').trim();
    if (value === 'bracket') return 'A';
    if (value === 'bracketB') return 'B';
    if (value === 'finals') return 'F';
    const match = value.match(/[ABF]/i);
    return match ? match[0].toUpperCase() : '';
  };
  const roundNumber = value => {
    const match = String(value || '').match(/(\\d+)/);
    return match ? parseInt(match[1], 10) : null;
  };
  const plainGame = game => {
    const letter = bracketLetter(game);
    const round = roundNumber(game && game.bracketRound);
    return {
      arena: String((game && game.arena) || ''),
      bracket: letter || null,
      bracketRound: letter ? `${letter}${round || ''}` : null,
      bracketGame: String((game && game.bracketGame) || ''),
      status: String((game && game.status) || '')
    };
  };
  const collectVueGameList = () => {
    const seen = new Set();
    const lists = [];
    const addList = list => {
      if (!Array.isArray(list)) return;
      const plain = Array.from(list).map(plainGame).filter(game => game.arena || game.bracket);
      if (plain.length) lists.push(plain);
    };
    const inspect = source => {
      if (!source) return;
      addList(source.gameList);
      if (source.$props) addList(source.$props.gameList);
      if (source.$data) addList(source.$data.gameList);
    };
    const visit = component => {
      let current = component;
      while (current && !seen.has(current)) {
        seen.add(current);
        inspect(current.proxy);
        inspect(current.props);
        inspect(current.ctx);
        inspect(current.setupState);
        inspect(current.data);
        current = current.parent;
      }
    };

    document.querySelectorAll('*').forEach(node => {
      if (node.__vueParentComponent) visit(node.__vueParentComponent);
      if (node.__vue_app__ && node.__vue_app__._instance) visit(node.__vue_app__._instance);
    });

    return lists
      .sort((a, b) => b.filter(game => game.bracket).length - a.filter(game => game.bracket).length || b.length - a.length)[0] || [];
  };

  const vueGameList = collectVueGameList();
  const gamesByLane = {};
  vueGameList.forEach(game => {
    const laneNumber = arenaLaneNumber(game.arena);
    if (laneNumber !== null) gamesByLane[laneNumber] = game;
  });

  const container = document.querySelector('.live-score');
  const isDuals = container ? container.classList.contains('duals') : false;

  const boxes = document.querySelectorAll('.live-score .box');
  const results = [];
  boxes.forEach((box, boxIndex) => {
    const laneEl = box.querySelector('.score-lane');
    const laneText = laneEl ? laneEl.innerText.trim() : '';
    const laneNumber = laneNumberFrom(laneText);
    const gameInfo = (laneNumber !== null ? gamesByLane[laneNumber] : null) || vueGameList[boxIndex] || {};

    const isBigAxe = box.classList.contains('bigAxeBox');

    const nameBlocks = box.querySelectorAll('.player-name .name');
    const names = Array.from(nameBlocks).map(n => {
      const span = n.querySelector('span');
      return span ? span.innerText.trim() : '';
    });
    const wonLastGame = Array.from(nameBlocks).map(n =>
      !!n.querySelector('i.text-green, i.mdi-checkbox-blank-circle.text-green')
    );

    const rows = box.querySelectorAll('.score-table .score-row');
    const players = [];
    rows.forEach((row, i) => {
      const throwCells = row.querySelectorAll('td.point .point-animate');
      const throws = Array.from(throwCells).map(c => c.innerText.trim());
      const sumCell = row.querySelector('td.point-sum');
      const roundTotal = sumCell ? sumCell.innerText.trim() : '0';
      players.push({
        name: names[i] || '',
        throws,
        roundTotal,
        wonLastGame: !!wonLastGame[i]
      });
    });

    if (players.length === 2 && players[0].name && players[1].name) {
      results.push({
        lane: laneText,
        isBigAxe,
        isDuals,
        bracket: gameInfo.bracket || null,
        bracketRound: gameInfo.bracketRound || null,
        bracketGame: gameInfo.bracketGame || null,
        players
      });
    }
  });
  return results;
}
"""


BRACKETS_JS = """
() => {
  const seedMap = {};
  const gameList = [];
  const displayName = player => {
    if (!player) return '';
    return (player.name || [player.first, player.last].filter(Boolean).join(' ')).trim();
  };
  const seedFor = player => {
    if (!player) return '';
    return String(player.seedPosition || player.seed || '').replace(/[^0-9]/g, '');
  };
  const bracketLetter = bracket => {
    if (bracket === 'bracket') return 'A';
    if (bracket === 'bracketB') return 'B';
    if (bracket === 'finals') return 'F';
    const match = String(bracket || '').match(/[ABF]/i);
    return match ? match[0].toUpperCase() : '';
  };
  const roundNumber = value => {
    const match = String(value || '').match(/(\\d+)/);
    return match ? parseInt(match[1], 10) : null;
  };
  const participantKey = game => game && (game.team1 || game.team2) ? 'team' : 'player';
  const addGame = (bracketName, roundKey, gameKey, game) => {
    if (!game) return;
    const participant = participantKey(game);
    const first = game[`${participant}1`];
    const second = game[`${participant}2`];
    const names = [displayName(first), displayName(second)].filter(Boolean);
    const letter = bracketLetter(bracketName);
    const round = letter ? `${letter}${roundNumber(roundKey) || ''}` : '';

    if (names.length === 2 && round) {
      gameList.push({ round, names });
    }

    [[first, names[0]], [second, names[1]]].forEach(([player, name]) => {
      const seed = seedFor(player);
      if (name && seed) seedMap[name] = seed;
    });
  };
  const addBracketObject = (bracketName, bracket) => {
    if (!bracket || typeof bracket !== 'object' || Array.isArray(bracket)) return;
    Object.entries(bracket).forEach(([roundKey, round]) => {
      if (!round || typeof round !== 'object') return;
      Object.entries(round).forEach(([gameKey, game]) => addGame(bracketName, roundKey, gameKey, game));
    });
  };
  const inspectVueSource = source => {
    if (!source) return;
    addBracketObject('bracket', source.bracket);
    addBracketObject('bracketB', source.bracketB);
    addBracketObject('finals', source.finals);
    const info = source.eventStore && source.eventStore.selectedTournamentBracketInfo;
    if (info) {
      addBracketObject('bracket', info.bracket);
      addBracketObject('bracketB', info.bracketB);
      addBracketObject('finals', info.finals);
    }
  };
  const collectVueBrackets = () => {
    const seen = new Set();
    const visit = component => {
      let current = component;
      while (current && !seen.has(current)) {
        seen.add(current);
        inspectVueSource(current.proxy);
        inspectVueSource(current.props);
        inspectVueSource(current.ctx);
        inspectVueSource(current.setupState);
        inspectVueSource(current.data);
        current = current.parent;
      }
    };

    document.querySelectorAll('*').forEach(node => {
      if (node.__vueParentComponent) visit(node.__vueParentComponent);
      if (node.__vue_app__ && node.__vue_app__._instance) visit(node.__vue_app__._instance);
    });
  };

  collectVueBrackets();

  if (!gameList.length) {
    const games = document.querySelectorAll('.bracket-game');
    games.forEach(g => {
      const textOf = el => el ? el.innerText.trim() : '';
      const roundCandidates = [
        g.querySelector('.roundGame p'),
        g.querySelector('.roundGame'),
        g.querySelector('[class*="roundGame"]'),
        g.querySelector('[class*="round-game"]')
      ];
      let round = roundCandidates.map(textOf).find(Boolean) || null;
      if (!round) {
        const fullText = textOf(g);
        const compactMatch = fullText.match(/\\b([ABF]\\d+)\\b/i);
        const gameMatch = fullText.match(/\\b([ABF])\\s*Game\\b/i);
        const bracketMatch = fullText.match(/\\bBracket\\s*([ABF])\\b/i);
        if (compactMatch) round = compactMatch[1].toUpperCase();
        else if (gameMatch) round = `${gameMatch[1].toUpperCase()} Game`;
        else if (bracketMatch) round = `Bracket ${bracketMatch[1].toUpperCase()}`;
      }

      const names = [];
      g.querySelectorAll('.player').forEach(p => {
        const nameSpan = p.querySelector('.name > span');
        const seedSpan = p.querySelector('.name .seed');
        const name = nameSpan ? nameSpan.innerText.trim() : '';
        if (name) {
          names.push(name);
          if (seedSpan) {
            const seed = seedSpan.innerText.trim().replace(/[^0-9]/g, '');
            if (seed) seedMap[name] = seed;
          }
        }
      });

      if (round && names.length === 2) {
        gameList.push({ round, names });
      }
    });
  }

  return { seedMap, gameList };
}
"""


STANDINGS_JS = """
() => {
  const theadRows = document.querySelectorAll('.tHead tr');
  if (theadRows.length < 2) return {};
  const headerCells = theadRows[1].querySelectorAll('th');
  const headers = Array.from(headerCells).map(th => {
    const div = th.querySelector('div');
    return div ? div.childNodes[0].textContent.trim() : th.innerText.trim();
  });

  const killsIdx = headers.indexOf('KILLS');
  const bullIdx = headers.indexOf('6');
  const lossIdx = headers.indexOf('L');

  const rows = document.querySelectorAll('#tableBody tr');
  const statsMap = {};
  rows.forEach(row => {
    const nameEl = row.querySelector('.leagueName');
    const name = nameEl ? nameEl.innerText.trim() : null;
    if (!name) return;
    const tds = row.querySelectorAll('td');
    const killsRaw = killsIdx >= 0 && tds[killsIdx] ? tds[killsIdx].innerText.trim() : null;
    const bullRaw = bullIdx >= 0 && tds[bullIdx] ? tds[bullIdx].innerText.trim() : null;
    const lossesRaw = lossIdx >= 0 && tds[lossIdx] ? tds[lossIdx].innerText.trim() : null;
    statsMap[name] = { killsRaw, bullRaw, lossesRaw };
  });
  return statsMap;
}
"""


def click_tab(page, labels, timeout=5000):
    if isinstance(labels, str):
        labels = [labels]

    for label in labels:
        try:
            page.get_by_text(label, exact=True).first.click(timeout=timeout)
            page.wait_for_timeout(500)
            return True
        except Exception:
            pass

    try:
        controls = page.query_selector_all("button, [role=button], a")
        for label in labels:
            wanted = label.strip().lower()
            for control in controls:
                text = control.inner_text().strip()
                if text.lower() == wanted:
                    control.click(force=True, timeout=timeout)
                    page.wait_for_timeout(500)
                    return True
        for label in labels:
            wanted = label.strip().lower()
            for control in controls:
                text = control.inner_text().strip().lower()
                if wanted and wanted in text:
                    control.click(force=True, timeout=timeout)
                    page.wait_for_timeout(500)
                    return True
    except Exception:
        pass
    return False


def scrape_brackets(page):
    click_tab(page, ["Tournament Brackets", "Brackets", "Bracket", "Playoffs"])
    page.wait_for_timeout(800)
    data = page.evaluate(BRACKETS_JS) or {"seedMap": {}, "gameList": []}
    seed_map = data.get("seedMap", {}) or {}
    game_index = {}
    top_player_map = {}
    for game in data.get("gameList", []) or []:
        names = game.get("names", [])
        if len(names) == 2:
            key = frozenset(names)
            game_index.setdefault(key, game.get("round"))
            top_player_map.setdefault(key, names[0])
    return seed_map, game_index, top_player_map


def scrape_live(page):
    click_tab(page, ["Live Games", "Live"])
    page.wait_for_timeout(350)
    return page.evaluate(LIVE_JS) or []


def scrape_standings(page):
    click_tab(page, ["Standings", "Stats"])
    page.wait_for_timeout(400)
    return page.evaluate(STANDINGS_JS) or {}


def parse_lane_number(lane_text):
    match = re.search(r"Lane\s*(\d+)", lane_text or "", re.IGNORECASE)
    return int(match.group(1)) if match else None


def parse_game_number(lane_text):
    match = re.search(r"Round\s*(\d+)", lane_text or "", re.IGNORECASE)
    return int(match.group(1)) if match else 1


def parse_bracket_letter(round_label):
    text = str(round_label or "").strip()
    if not text:
        return None
    if re.fullmatch(r"[A-Za-z]", text):
        return text.upper()
    patterns = [
        r"^([A-Za-z]+)\d+",
        r"^([A-Za-z]+)\s*game",
        r"^game\s*([A-Za-z]+)",
        r"^bracket\s*([A-Za-z]+)",
        r"\bbracket\s*([A-Za-z]+)\b",
        r"\b([AB])\s*game\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(1).upper()
    return None


def lookup_bracket_round(game_index, name1, name2):
    round_label = game_index.get(frozenset([name1, name2]))
    if not round_label:
        return None, None
    return parse_bracket_letter(round_label), round_label


GAME_FORMATS = {
    "hatchet": {"throws_per_game": 10, "mid_game_switch_throw": 5, "throw_display_group": 1},
    "big_axe": {"throws_per_game": 7, "mid_game_switch_throw": None, "throw_display_group": 1},
    "duals": {"throws_per_game": 10, "mid_game_switch_throw": None, "throw_display_group": 2},
}


def compute_targets_swapped(game_number, current_game_min_throw_count, format_key="hatchet"):
    previous_game_switches = max(game_number - 1, 0)
    switch_throw = GAME_FORMATS.get(format_key, GAME_FORMATS["hatchet"])["mid_game_switch_throw"]
    current_game_switch = 1 if switch_throw is not None and current_game_min_throw_count >= switch_throw else 0
    return (previous_game_switches + current_game_switch) % 2 == 1


def parse_bull_pct(bull_raw):
    if not bull_raw or bull_raw.strip() == "-":
        return 0.0
    match = re.search(r"([\d.]+)\s*%", bull_raw)
    return float(match.group(1)) if match else 0.0


def parse_bull_count(bull_raw):
    if not bull_raw:
        return 0
    match = re.search(r"\((\d+)\)", bull_raw)
    return int(match.group(1)) if match else 0


def infer_baseline_throws(bull_pct, bull_count):
    if not bull_pct or bull_pct <= 0 or not bull_count:
        return 0
    return round(bull_count / (bull_pct / 100))


def parse_kill_pct(kills_raw):
    if not kills_raw or kills_raw.strip() == "-":
        return 0.0
    if "/" not in kills_raw:
        return None
    try:
        makes, attempts = kills_raw.split("/")
        makes, attempts = float(makes), float(attempts)
        if attempts == 0:
            return 0.0
        return round(makes / attempts * 100, 1)
    except ValueError:
        return None


def safe_int(value, default=0):
    try:
        return int(str(value or "").strip())
    except ValueError:
        return default


def compute_tournament_status(seed_map, game_index, standings_map):
    total_players = len(seed_map)
    if total_players == 0:
        return None

    has_bracket_b = any(
        parse_bracket_letter(round_label) == "B" for round_label in game_index.values()
    )
    lives = 2 if has_bracket_b else 1

    eliminated = 0
    for name in seed_map:
        stats = standings_map.get(name, {})
        losses = safe_int(stats.get("lossesRaw"), 0)
        if losses >= lives:
            eliminated += 1

    remaining = max(total_players - eliminated, 0)
    buckets = [2, 4, 8, 16, 32, 64, 128, 256]
    top_label = next((f"Top {bucket}" for bucket in buckets if remaining <= bucket), f"Top {remaining}")
    if remaining <= 1:
        top_label = "Final"

    return {"totalPlayers": total_players, "remaining": remaining, "topLabel": top_label}


GAMES_TO_WIN_MATCH = 2
_match_win_state = {}


def update_match_win_tracking(lane):
    players = lane.get("players", [])
    if len(players) != 2:
        return None

    names = [p["name"] for p in players]
    pairing_key = (frozenset(names), lane.get("bracketRound"))
    state = _match_win_state.setdefault(pairing_key, {"wins": {}, "counted_games": set()})

    game_number = lane.get("gameNumber", 1)
    throws_per_game = lane.get("throwsPerGame", 10)
    min_throws = min((len(p.get("throws", [])) for p in players), default=0)
    game_complete = min_throws >= throws_per_game

    if game_complete and game_number not in state["counted_games"]:
        home_total = safe_int(players[0].get("roundTotal"), 0)
        away_total = safe_int(players[1].get("roundTotal"), 0)
        if home_total != away_total:
            winner_name = players[0]["name"] if home_total > away_total else players[1]["name"]
            state["wins"][winner_name] = state["wins"].get(winner_name, 0) + 1
        state["counted_games"].add(game_number)

    for name, wins in state["wins"].items():
        if wins >= GAMES_TO_WIN_MATCH:
            return name
    return None


def build_payload(lanes, seed_map, game_index, top_player_map, standings_map):
    tournament_status = compute_tournament_status(seed_map, game_index, standings_map)

    for lane in lanes:
        lane["laneNumber"] = parse_lane_number(lane.get("lane", ""))
        players = lane.get("players", [])
        names = [p.get("name", "") for p in players]

        live_round = lane.get("bracketRound")
        live_bracket = str(lane.get("bracket") or "").strip().upper() or None
        bracket_letter = parse_bracket_letter(live_round) or parse_bracket_letter(live_bracket) or live_bracket
        round_label = live_round

        if len(names) == 2 and (not bracket_letter or not round_label):
            fallback_letter, fallback_round = lookup_bracket_round(game_index, names[0], names[1])
            bracket_letter = bracket_letter or fallback_letter
            round_label = round_label or fallback_round

        lane["bracket"] = bracket_letter
        lane["bracketRound"] = round_label

        for player in players:
            name = player["name"]
            player["seed"] = seed_map.get(name)

            stats = standings_map.get(name, {})
            baseline_pct = parse_bull_pct(stats.get("bullRaw"))
            baseline_count = parse_bull_count(stats.get("bullRaw"))
            baseline_throws = infer_baseline_throws(baseline_pct, baseline_count)

            live_throws = player.get("throws", [])
            live_bull_hits = sum(1 for t in live_throws if str(t).strip() == "6")
            total_bull = baseline_count + live_bull_hits
            total_throws = baseline_throws + len(live_throws)
            player["bullPct"] = round(total_bull / total_throws * 100, 1) if total_throws > 0 else 0.0
            player["killPct"] = parse_kill_pct(stats.get("killsRaw"))

        format_key = "duals" if lane.get("isDuals") else "big_axe" if lane.get("isBigAxe") else "hatchet"
        format_info = GAME_FORMATS[format_key]
        lane["format"] = format_key
        lane["throwsPerGame"] = format_info["throws_per_game"]
        lane["throwDisplayGroup"] = format_info["throw_display_group"]

        game_number = parse_game_number(lane.get("lane", ""))
        current_game_min_throw_count = min((len(p.get("throws", [])) for p in players), default=0)
        lane["gameNumber"] = game_number
        swapped = compute_targets_swapped(game_number, current_game_min_throw_count, format_key)
        lane["targetsSwapped"] = swapped

        top_name = top_player_map.get(frozenset(names)) if len(names) == 2 else None
        by_name = {p["name"]: p for p in players}
        other_name = next((name for name in names if name != top_name), None)
        if top_name in by_name and other_name in by_name:
            baseline_order = [by_name[other_name], by_name[top_name]]
        else:
            baseline_order = players
        lane["players"] = list(reversed(baseline_order)) if swapped else baseline_order

        lane["matchWinner"] = update_match_win_tracking(lane)

    return {
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "active_matches": lanes,
        "has_live": len(lanes) > 0,
        "tournament_status": tournament_status,
    }


class ScraperWorker:
    def __init__(self, output_path: Path, log_fn):
        self.output_path = output_path
        self.log = log_fn
        self.stop_event = threading.Event()
        self.thread = None

    def start(self, url, interval=POLL_SECONDS, refresh_every=STATS_REFRESH_EVERY):
        self.stop_event.clear()
        self.thread = threading.Thread(
            target=self._run, args=(url, interval, refresh_every), daemon=True
        )
        self.thread.start()

    def stop(self):
        self.stop_event.set()

    def _run(self, url, interval, refresh_every):
        if sync_playwright is None:
            self.log("Playwright is not installed yet. Run the setup file for this computer first.")
            self.log(str(PLAYWRIGHT_IMPORT_ERROR))
            return

        self.log(f"Starting scraper for: {url}")
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch()
                page = browser.new_page()

                seed_map, game_index, top_player_map, standings_map = {}, {}, {}, {}
                cycle = 0
                first_load = True

                while not self.stop_event.is_set():
                    try:
                        if first_load:
                            page.goto(url, wait_until="networkidle", timeout=60000)
                            page.wait_for_timeout(2000)

                        if first_load or (cycle % refresh_every == 0):
                            new_seed_map, new_game_index, new_top_player_map = scrape_brackets(page)
                            seed_map = new_seed_map or seed_map
                            game_index = new_game_index or game_index
                            top_player_map = new_top_player_map or top_player_map
                            standings_map = scrape_standings(page) or standings_map
                            preview = ", ".join(str(v) for v in list(game_index.values())[:6])
                            if preview:
                                preview = f" [{preview}]"
                            self.log(
                                f"Refreshed seeds ({len(seed_map)}), games ({len(game_index)}){preview}, "
                                f"standings ({len(standings_map)})"
                            )

                        lanes = scrape_live(page)
                        first_load = False

                        payload = build_payload(lanes, seed_map, game_index, top_player_map, standings_map)
                        self.output_path.write_text(json.dumps(payload, indent=2))
                        self.log(f"[{payload['updated_at']}] OK - {len(lanes)} live lane(s).")
                    except Exception:
                        self.log("Scrape failed. It will retry automatically:")
                        self.log(traceback.format_exc())
                        first_load = True

                    cycle += 1
                    for _ in range(interval * 10):
                        if self.stop_event.is_set():
                            break
                        time.sleep(0.1)

                browser.close()
        except Exception:
            self.log("Scraper crashed:")
            self.log(traceback.format_exc())
        self.log("Scraper stopped.")


class QuietRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Pragma", "no-cache")
        super().end_headers()

    def log_message(self, format, *args):
        return


class ServerWorker:
    def __init__(self, log_fn):
        self.log = log_fn
        self.httpd = None
        self.thread = None

    def start(self, directory, port=SERVER_PORT):
        if self.httpd:
            return True
        try:
            handler = functools.partial(QuietRequestHandler, directory=str(directory))
            self.httpd = http.server.ThreadingHTTPServer(("localhost", port), handler)
            self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
            self.thread.start()
            self.log(f"Local overlay server running at http://localhost:{port}/")
            return True
        except OSError as exc:
            self.httpd = None
            self.log(f"Could not start the local overlay server: {exc}")
            return False

    def stop(self):
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None
            self.log("Local overlay server stopped.")


class App:
    PLACEHOLDER_COLOR = "#8a8172"
    NORMAL_COLOR = "#000000"

    def __init__(self, root, config: PlatformConfig):
        self.root = root
        self.config = config
        self.app_dir = ensure_runtime_files(config)
        self.output_path = self.app_dir / config.scores_filename
        self.overlay_base_url = f"http://localhost:{SERVER_PORT}/{config.overlay_filename}"

        self.root.title(f"{config.app_title} - {config.platform_name}")
        self.root.geometry("760x680")
        self.root.minsize(700, 600)

        self.log_queue = queue.Queue()
        self.scraper = ScraperWorker(self.output_path, self._queue_log)
        self.server = ServerWorker(self._queue_log)
        self.running = False
        self.lane_vars = []
        self.url_rows = []

        self._build_ui()
        self._rebuild_lane_inputs()
        self._update_urls()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.after(150, self._drain_log_queue)

    def _set_placeholder(self, entry, text):
        entry.insert(0, text)
        entry.configure(foreground=self.PLACEHOLDER_COLOR)

        def on_focus_in(_event):
            if entry.get() == text:
                entry.delete(0, "end")
                entry.configure(foreground=self.NORMAL_COLOR)

        def on_focus_out(_event):
            if not entry.get():
                entry.insert(0, text)
                entry.configure(foreground=self.PLACEHOLDER_COLOR)

        entry.bind("<FocusIn>", on_focus_in)
        entry.bind("<FocusOut>", on_focus_out)

    def _entry_value(self, entry, placeholder):
        value = entry.get().strip()
        return "" if value == placeholder else value

    def _build_ui(self):
        pad = {"padx": 12, "pady": 6}

        url_frame = ttk.Frame(self.root)
        url_frame.pack(fill="x", **pad)
        ttk.Label(url_frame, text="Tournament URL").pack(anchor="w")
        self.url_entry = ttk.Entry(url_frame)
        self.url_entry.pack(fill="x", pady=(4, 0))
        self._set_placeholder(self.url_entry, "Paste the live tournament URL here")

        options_frame = ttk.LabelFrame(self.root, text="Overlay Options")
        options_frame.pack(fill="x", **pad)

        count_row = ttk.Frame(options_frame)
        count_row.pack(fill="x", padx=10, pady=(8, 4))
        ttk.Label(count_row, text="Number of lane overlays needed").pack(side="left")
        self.lane_overlay_count_var = tk.StringVar(value="1")
        count_entry = ttk.Entry(count_row, width=6, textvariable=self.lane_overlay_count_var)
        count_entry.pack(side="left", padx=(10, 20))
        ttk.Button(count_row, text="Update Lane Boxes", command=self._rebuild_lane_inputs).pack(side="left")

        ttk.Label(count_row, text="Scrolling overlay seconds").pack(side="left", padx=(20, 0))
        self.scroll_seconds_var = tk.StringVar(value="10")
        scroll_entry = ttk.Entry(count_row, width=6, textvariable=self.scroll_seconds_var)
        scroll_entry.pack(side="left", padx=(10, 0))
        scroll_entry.bind("<KeyRelease>", lambda _event: self._update_urls())
        scroll_entry.bind("<FocusOut>", lambda _event: self._update_urls())

        self.lanes_frame = ttk.Frame(options_frame)
        self.lanes_frame.pack(fill="x", padx=10, pady=(2, 10))

        button_frame = ttk.Frame(self.root)
        button_frame.pack(fill="x", **pad)
        self.start_btn = ttk.Button(button_frame, text="Start", command=self._on_start)
        self.start_btn.pack(side="left", padx=(0, 8))
        self.stop_btn = ttk.Button(button_frame, text="Stop", command=self._on_stop, state="disabled")
        self.stop_btn.pack(side="left", padx=(0, 8))
        self.open_btn = ttk.Button(button_frame, text="Open All Lanes Preview", command=self._on_open_overlay)
        self.open_btn.pack(side="left")

        self.status_label = ttk.Label(self.root, text="Status: Stopped", foreground="#a33")
        self.status_label.pack(anchor="w", padx=12)

        self.urls_frame = ttk.LabelFrame(self.root, text="OBS Browser Source URLs")
        self.urls_frame.pack(fill="x", **pad)

        log_frame = ttk.Frame(self.root)
        log_frame.pack(fill="both", expand=True, **pad)
        ttk.Label(log_frame, text="Status Log").pack(anchor="w")
        self.log_text = tk.Text(log_frame, height=10, state="disabled", bg="#17140f", fg="#ede4d3")
        self.log_text.pack(fill="both", expand=True, pady=(4, 0))

    def _lane_overlay_count(self):
        value = safe_int(self.lane_overlay_count_var.get(), 1)
        value = max(0, min(value, 24))
        self.lane_overlay_count_var.set(str(value))
        return value

    def _rebuild_lane_inputs(self):
        existing = [var.get() for var in self.lane_vars]
        for child in self.lanes_frame.winfo_children():
            child.destroy()
        self.lane_vars = []

        count = self._lane_overlay_count()
        if count == 0:
            ttk.Label(self.lanes_frame, text="No single-lane overlays selected.").pack(anchor="w")
            self._update_urls()
            return

        for index in range(count):
            row = ttk.Frame(self.lanes_frame)
            row.pack(fill="x", pady=3)
            ttk.Label(row, text=f"Overlay {index + 1}", width=10).pack(side="left")
            ttk.Label(row, text="Number of the lane for stream overlay").pack(side="left")
            var = tk.StringVar(value=existing[index] if index < len(existing) else "")
            var.trace_add("write", lambda *_args: self._update_urls())
            entry = ttk.Entry(row, width=8, textvariable=var)
            entry.pack(side="left", padx=(10, 0))
            self.lane_vars.append(var)

        self._update_urls()

    def _valid_lane_numbers(self):
        lanes = []
        seen = set()
        for var in self.lane_vars:
            text = var.get().strip()
            if not text.isdigit():
                continue
            lane = int(text)
            if lane <= 0 or lane in seen:
                continue
            lanes.append(lane)
            seen.add(lane)
        return lanes

    def _scroll_seconds(self):
        value = safe_int(self.scroll_seconds_var.get(), 10)
        return max(1, min(value, 600))

    def _url_with_params(self, **params):
        clean = {key: value for key, value in params.items() if value not in (None, "")}
        return self.overlay_base_url if not clean else f"{self.overlay_base_url}?{urlencode(clean)}"

    def _scrolling_url(self):
        lanes = self._valid_lane_numbers()
        exclude = ",".join(str(lane) for lane in lanes)
        return self._url_with_params(scrolling="1", seconds=str(self._scroll_seconds()), exclude=exclude)

    def _clear_url_rows(self):
        for child in self.urls_frame.winfo_children():
            child.destroy()
        self.url_rows = []

    def _add_url_row(self, label, url, note=None):
        row = ttk.Frame(self.urls_frame)
        row.pack(fill="x", padx=10, pady=4)
        ttk.Label(row, text=label, width=28).pack(side="left")
        value = tk.StringVar(value=url)
        entry = ttk.Entry(row, textvariable=value, state="readonly")
        entry.pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Copy", command=lambda v=value, l=label: self._copy_url(v.get(), l)).pack(
            side="left", padx=(8, 0)
        )
        if note:
            ttk.Label(self.urls_frame, text=note, foreground="#666").pack(anchor="w", padx=10)
        self.url_rows.append((label, value))

    def _update_urls(self):
        if not hasattr(self, "urls_frame"):
            return
        self._clear_url_rows()
        self._add_url_row("All live lanes", self.overlay_base_url)
        lanes = self._valid_lane_numbers()
        note = "Scrolling Overlay skips the stream lanes listed above." if lanes else "Scrolling Overlay rotates through all live lanes."
        self._add_url_row("Scrolling Overlay", self._scrolling_url(), note=note)
        for lane in lanes:
            self._add_url_row(f"Lane {lane} overlay", self._url_with_params(lane=str(lane)))

    def _queue_log(self, message):
        self.log_queue.put(message)

    def _drain_log_queue(self):
        try:
            while True:
                message = self.log_queue.get_nowait()
                self.log_text.configure(state="normal")
                self.log_text.insert("end", message + "\n")
                self.log_text.see("end")
                self.log_text.configure(state="disabled")
        except queue.Empty:
            pass
        self.root.after(150, self._drain_log_queue)

    def _on_start(self):
        if self.running:
            return
        url = self._entry_value(self.url_entry, "Paste the live tournament URL here")
        if not url:
            self._queue_log("Please paste a tournament URL first.")
            return

        if not self.server.start(self.app_dir, SERVER_PORT):
            return
        self.scraper.start(url)
        self.running = True
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.status_label.configure(text="Status: Running", foreground="#2a7")

    def _on_stop(self):
        if not self.running:
            return
        self.scraper.stop()
        self.server.stop()
        self.running = False
        self.start_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self.status_label.configure(text="Status: Stopped", foreground="#a33")

    def _on_open_overlay(self):
        webbrowser.open(self.overlay_base_url)

    def _copy_url(self, url, label):
        self.root.clipboard_clear()
        self.root.clipboard_append(url)
        self._queue_log(f"Copied {label} URL to clipboard.")

    def _on_close(self):
        if self.running:
            self._on_stop()
        self.root.destroy()


def _report_crash(config: PlatformConfig, exc_type, exc_value, exc_tb):
    message = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    try:
        log_path = _app_dir() / config.crash_log_filename
        log_path.write_text(message)
    except Exception:
        log_path = None

    try:
        import tkinter.messagebox as messagebox

        note = f"\n\nAlso saved to {log_path.name}" if log_path else ""
        messagebox.showerror("WATL Overlay App crashed", message[-1500:] + note)
    except Exception:
        try:
            import ctypes

            if hasattr(ctypes, "windll"):
                ctypes.windll.user32.MessageBoxW(
                    0, message[-1500:], "WATL Overlay App crashed", 0x10
                )
        except Exception:
            pass


def run_app(config: PlatformConfig):
    try:
        root = tk.Tk()
        root.report_callback_exception = lambda *exc_info: _report_crash(config, *exc_info)
        app = App(root, config)
        root.mainloop()
    except Exception:
        _report_crash(config, *sys.exc_info())


if __name__ == "__main__":
    run_app(
        PlatformConfig(
            platform_name="Mac",
            overlay_filename="Mac-overlay.html",
            scores_filename="Mac-scores.json",
            crash_log_filename="Mac-crash-log.txt",
        )
    )

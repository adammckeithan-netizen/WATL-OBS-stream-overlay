#!/bin/bash
cd "$(dirname "$0")"
exec ./Mac-setup.sh

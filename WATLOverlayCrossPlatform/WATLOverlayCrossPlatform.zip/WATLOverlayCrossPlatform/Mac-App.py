from OverlayCore import PlatformConfig, run_app


if __name__ == "__main__":
    run_app(
        PlatformConfig(
            platform_name="Mac",
            overlay_filename="Mac-overlay.html",
            scores_filename="Mac-scores.json",
            crash_log_filename="Mac-crash-log.txt",
        )
    )

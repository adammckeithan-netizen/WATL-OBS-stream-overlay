#!/bin/bash
set -e

cd "$(dirname "$0")"

if [ -x ".venv/bin/activate" ]; then
  . .venv/bin/activate
fi

python -m PyInstaller --windowed --onefile \
  --name "WATL-Overlay-Mac" \
  --add-data "Mac-overlay.html:." \
  --add-data "Mac-scores.json:." \
  Mac-App.py

echo
echo "Mac app build is in the dist folder."

@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  set "PY=python"
)

%PY% -m venv .venv
if errorlevel 1 goto setup_error

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install playwright pyinstaller
python -m playwright install chromium

echo.
echo Windows setup is done. You can start the app with Windows-start.bat.
pause
exit /b 0

:setup_error
echo.
echo Setup could not create the app environment. Make sure Python 3 is installed.
pause
exit /b 1

from OverlayCore import PlatformConfig, run_app


if __name__ == "__main__":
    run_app(
        PlatformConfig(
            platform_name="Windows",
            overlay_filename="Windows-overlay.html",
            scores_filename="Windows-scores.json",
            crash_log_filename="Windows-crash-log.txt",
        )
    )

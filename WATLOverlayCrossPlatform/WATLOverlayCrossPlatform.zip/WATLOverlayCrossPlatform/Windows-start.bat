@echo off
cd /d "%~dp0"

if exist ".venv\Scripts\pythonw.exe" (
  start "" ".venv\Scripts\pythonw.exe" "%~dp0Windows-App.py"
  exit /b 0
)

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 Windows-App.py
) else (
  python Windows-App.py
)

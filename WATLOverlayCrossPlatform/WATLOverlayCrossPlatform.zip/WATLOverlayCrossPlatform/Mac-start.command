#!/bin/bash
cd "$(dirname "$0")"

if [ -x ".venv/bin/python" ]; then
  exec .venv/bin/python Mac-App.py
fi

exec python3 Mac-App.py

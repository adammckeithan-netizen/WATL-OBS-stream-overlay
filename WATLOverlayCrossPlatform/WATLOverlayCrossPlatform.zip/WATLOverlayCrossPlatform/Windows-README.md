# WATL Overlay App - Windows

Use these files on Windows:

- `Windows-setup.bat` installs what the app needs.
- `Windows-start.bat` starts the app.
- `Windows-App.py` is the Windows launcher.
- `Windows-overlay.html` is the Windows OBS overlay page.
- `Windows-scores.json` is the Windows live score data file.
- `Windows-build-exe.bat` is optional and builds a Windows `.exe`.

## First Setup

1. Install Python 3 for Windows if it is not installed yet.
2. Double-click `Windows-setup.bat`.
3. Wait for it to say setup is done.

Setup only needs to be done once on each Windows computer.

## Start The App

Double-click `Windows-start.bat`.

Paste the tournament URL, choose how many lane overlays you need, enter the lane numbers, then press Start.

## OBS Links

The app shows these OBS Browser Source links:

- All live lanes
- Scrolling Overlay
- One copy button for each selected stream lane

The Scrolling Overlay skips the lanes selected for stream overlays.

## Optional Build

Double-click `Windows-build-exe.bat` on a Windows computer to create:

`dist\WATL-Overlay-Windows.exe`

That `.exe` is the easiest file to give to another Windows user after it is built.
